#ifndef RELOCATE_H
#define RELOCATE_H

#include "Solucion.h"

void relocate(Solucion & s, const VRPLIBReader & instance);

#endif